import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import type { ChatInputCommandInteraction, Client } from "discord.js";
import { PermissionFlagsBits, SlashCommandBuilder } from "discord.js";

import { builder as clearBuilder } from "./clear.js";
import { builder as setBuilder } from "./set.js";
import { builder as viewBuilder } from "./view.js";

const command: Command = {
	data: new SlashCommandBuilder()
		.setName("config")
		.setDescription("Change the server settings the bot uses")
		.setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

		.addSubcommand(setBuilder)
		.addSubcommand(clearBuilder)
		.addSubcommand(viewBuilder),

	async execute(interaction: ChatInputCommandInteraction, client: Client) {
		if (!interaction.guild) {
			await interaction.reply("This command can only be used in a server.");
			return;
		}

		const subcommand = interaction.options.getSubcommand();

		const __dirname = path.dirname(fileURLToPath(import.meta.url));

		// Use the same extension as the current file (.ts during dev and .js after build)
		const currentExt = path.extname(fileURLToPath(import.meta.url)) || ".ts";
		const subPath = path.join(__dirname, subcommand + currentExt);

		try {
			const imported = await import(pathToFileURL(subPath).href);
			const handler = imported?.default;

			if (typeof handler !== "function") {
				await interaction.reply(`Unknown or invalid subcommand: ${subcommand}`);
				return;
			}

			await handler(interaction, client);
		} catch (err) {
			console.error("Failed to load subcommand handler:", err);
			await interaction.reply(`Error loading subcommand: ${subcommand}`);
		}
	},
};

export default command;
