import type { ChatInputCommandInteraction, Client } from "discord.js";
import {
	EmbedBuilder,
	MessageFlags,
	PermissionFlagsBits,
	SlashCommandBuilder,
} from "discord.js";

import type { UserProfileKey } from "../../utils/profileManager.js";
import { FindByValue } from "../../utils/profileManager.js";
import { getDisplayName } from "../../utils/memberUtils.js";

const command: Command = {
	data: new SlashCommandBuilder()
		.setName("lookup")
		.setDescription("String lookup for user profiles (for support only)")
		.setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
		.addStringOption((option) => {
			const userProfileKeys = [
				"id",
				"discordId",
				"serverId",
				"verifycode",
				"email",
			] as const satisfies readonly UserProfileKey[];
			return option
				.setName("lookup")
				.setDescription("Key to lookup")
				.setRequired(true)
				.addChoices(
					...userProfileKeys.map((key) => ({ name: key, value: key })),
				);
		})
		.addStringOption((option) =>
			option
				.setName("string")
				.setDescription("String to lookup")
				.setRequired(false),
		),

	async execute(interaction: ChatInputCommandInteraction, _client: Client) {
		await interaction.deferReply({ flags: MessageFlags.Ephemeral });

		const lookup = interaction.options.getString(
			"lookup",
			true,
		) as UserProfileKey;
		const value = interaction.options.getString("string", false);

		const result = await FindByValue(lookup, value);

		if (!result) {
			await interaction.editReply({
				content: "No user found with the given key and value.",
			});
			return;
		}

		const embed = new EmbedBuilder()
			.setTitle("User Found")
			.setDescription(`Result: <@${result.discordId}> (${getDisplayName(interaction.guild, result.discordId)})`)
			.setThumbnail(
				interaction.guild?.members.cache
					.get(result.discordId)
					?.user.displayAvatarURL() as string,
			)
			.setAuthor({
				name: `Lookup for key:"${lookup}" with value:"${value}"`,
				iconURL: interaction.user.displayAvatarURL(),
			})
			.setColor("DarkNavy");

		for (const [key, val] of Object.entries(result)) {
			// the moderation list can get way too long for an embed
			const displayValue =
				key === "moderation" && Array.isArray(val)
					? `${val.length} entries (use /moderation history)`
					: typeof val === "object" && val !== null
						? JSON.stringify(val, null, 2)
						: String(val);
			if (displayValue === "null" || displayValue === "undefined") continue;
			embed.addFields({ name: key, value: displayValue.slice(0, 1024), inline: false });
		}

		await interaction.editReply({
			embeds: [embed],
		});
	},
};

export default command;
