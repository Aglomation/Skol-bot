const autocomplete = {
    data: {
        name: "empty",
    },
    async execute(interaction, _client) {
        await interaction.respond([]);
    },
};
export default autocomplete;
