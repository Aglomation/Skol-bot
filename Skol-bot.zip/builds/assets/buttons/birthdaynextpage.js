import { generateBirthdayPage } from "../commands/birthday/list.js";
const button = {
    data: {
        customId: "birthdaychangepage",
    },
    async execute(interaction, _client) {
        const page = parseInt(interaction.customId.split(":")[1], 10) || 1;
        const pageData = await generateBirthdayPage(page, interaction.guild);
        if (!pageData) {
            await interaction.update({
                content: "No birthdays found.",
                embeds: [],
                components: [],
            });
            return;
        }
        await interaction.update(pageData);
    },
};
export default button;
