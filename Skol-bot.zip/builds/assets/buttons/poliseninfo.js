import fs from "node:fs/promises";
import path from "node:path";
import axios from "axios";
import * as cheerio from "cheerio";
import { EmbedBuilder, MessageFlags } from "discord.js";
const CACHE_DIR = "./cache";
const CACHE_FILE = path.join(CACHE_DIR, "polisen.json");
async function loadCache() {
    try {
        await fs.mkdir(CACHE_DIR, { recursive: true });
        const data = await fs.readFile(CACHE_FILE, "utf-8");
        const parsedData = JSON.parse(data);
        return new Map(parsedData.map((item) => [item.id, item]));
    }
    catch {
        return new Map(); // Return empty map if file doesn't exist or is invalid
    }
}
/**
 * Scrapes the individual event article for updates and details.
 */
async function scrapeEventDetails(url) {
    const { data } = await axios.get(`https://polisen.se${url}`, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
        },
    });
    const $ = cheerio.load(data);
    const contentDiv = $('div.event-page.editorial-content').eq(0);
    const lastUpdated = contentDiv.
        find('span.text')
        .first()
        .text()
        .trim() || null;
    const mainContent = contentDiv.
        find('div.text-body.editorial-html')
        .first()
        .text()
        .trim() || "No additional details provided.";
    const writer = contentDiv.
        find('div.page-meta-data')
        .first()
        .find('dd')
        .first()
        .text()
        .trim() || "Okänd";
    return { lastUpdated, mainContent, writer };
}
/**
 * Formats the raw scraped text to make it readable for Discord embeds.
 */
const formatMainContent = (text) => {
    if (!text)
        return "";
    let formatted = text.replace(/([^\n])\n([^\n])/g, "$1\n\n$2");
    // 2. Process line-by-line to catch updates and timestamps
    formatted = formatted
        .split("\n")
        .map((line) => {
        const trimmed = line.trim();
        if (!trimmed)
            return line;
        const timeRegex = /(?:Uppdatering(?:\s+\d{1,2}[:.]\d{2})?:?|\b\d{1,2}[:.]\d{2}\b)/i;
        if (trimmed.length < 20 && timeRegex.test(trimmed)) {
            return `📝 **${trimmed}**`;
        }
        return line;
    })
        .join("\n");
    return formatted;
};
const truncateText = (text, maxLength) => {
    if (!text)
        return "";
    return text.length > maxLength ? `${text.substring(0, maxLength - 3)}...` : text;
};
const button = {
    data: {
        customId: "poliseninfo",
    },
    async execute(interaction, _client) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const id = parseInt(interaction.customId.split(":")[1], 10) || null;
        if (!id) {
            await interaction.editReply({
                content: "Invalid page number.",
            });
            return;
        }
        const database = await loadCache();
        const event = database.get(id);
        if (!event) {
            await interaction.editReply({
                content: "Event not found in local database, erm contact Vera.",
            });
            return;
        }
        // webscrape the page for more info
        const { lastUpdated, mainContent, writer } = await scrapeEventDetails(event.url);
        const time = new Date(`${event.name.match(/(\d{1,2} \w+) \d{2}\.\d{2}/)?.[0].replace(".", ":")} ${new Date().getFullYear()}` || 0);
        const embed = new EmbedBuilder()
            .setTitle(event.name)
            .setURL(`https://polisen.se${event.url}`)
            // Put main content in the description to utilize the 4096 char limit
            .setDescription(truncateText(formatMainContent(mainContent), 4000))
            .addFields({ name: "Typ", value: event.type, inline: true }, { name: "Plats", value: `[${event.location.name}](https://www.google.com/maps/search/${encodeURIComponent(event.location.name)})`, inline: true }, { name: "Tid", value: `<t:${Math.floor(time.getTime() / 1000)}:R>`, inline: true }, { name: "Skribent", value: writer || "Okänd", inline: true })
            .setColor(0x005293)
            .setFooter({
            text: `${lastUpdated ? lastUpdated : "Polisen.se"} ・ Publicerad ${new Date(event.datetime).toLocaleString()}`,
            iconURL: "https://polisen.se/images/icons/favicon-32x32.png"
        });
        // Actually send the embed instead of dumping raw text
        await interaction.editReply({
            content: null, // Clear out any previous text
            embeds: [embed],
        });
    },
};
export default button;
