import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MessageFlags, PermissionFlagsBits, PermissionsBitField, } from "discord.js";
import { GetServerConfig } from "../../../utils/configManager.js";
import button from "../../buttons/verify.js";
export const builder = (subcommand) => subcommand
    .setName("verifymessage")
    .setDescription("Sends the message with button for verification");
export default async function command(interaction, client) {
    if (!interaction.guild)
        return;
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    // Check if the user has the "Ban Members" permission, which assumes you're a moderator or admin
    const executor = interaction.member;
    if (!executor.permissions.has(PermissionsBitField.Flags.BanMembers) && await GetServerConfig(interaction.guild.id, "isDevServer") === false) {
        await interaction.editReply("You don't have permission to use this.");
        return;
    }
    const embed = new EmbedBuilder()
        .setTitle("Verifiera din LBS-mejl 🔒")
        .setDescription("Klicka på knappen nedan och läs reglerna i <#1497140071176863759> för att komma in på servern.")
        .setFooter({ text: "Använd /privacy policy för att läsa vår integritetspolicy. :3" })
        .setColor(0x87CFEB);
    const btn = new ButtonBuilder()
        .setCustomId(button.data.customId)
        .setLabel("Verifiera Här!")
        .setEmoji("✅")
        .setStyle(ButtonStyle.Success);
    const row = new ActionRowBuilder().addComponents(btn);
    const channel = client.channels.cache.get(interaction.channel?.id);
    if (!client?.user || !channel?.permissionsFor(client.user)?.has(PermissionFlagsBits.SendMessages))
        return;
    await channel.send({ embeds: [embed], components: [row] });
    await interaction.deleteReply();
}
