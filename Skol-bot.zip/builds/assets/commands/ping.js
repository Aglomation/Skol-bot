import { MessageFlags, SlashCommandBuilder } from "discord.js";
const command = {
    data: new SlashCommandBuilder()
        .setName("ping")
        .setDescription("Checks the bot latency"),
    async execute(interaction, client) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const sent = await interaction.fetchReply();
        const roundtrip = sent.createdTimestamp - interaction.createdTimestamp;
        const websocket = client.ws.ping;
        await interaction.editReply({
            content: `Pong!\nRoundtrip: \`${roundtrip}ms\`\nWebSocket: \`${websocket}ms\``,
        });
    },
};
export default command;
