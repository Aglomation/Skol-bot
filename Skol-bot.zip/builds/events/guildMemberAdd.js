import { EmbedBuilder, Events, PermissionFlagsBits } from "discord.js";
import { GetServerConfig } from "../utils/configManager.js";
import { GetActiveBan } from "../utils/moderationManager.js";
import { GetProfile } from "../utils/profileManager.js";
export default {
    name: Events.GuildMemberAdd,
    once: false,
    async execute(member, client) {
        const profile = await GetProfile(member.id, member.guild.id);
        // Check if the user is banned
        const isBanned = await handleSoftBanCheck(member, profile);
        if (isBanned)
            return;
        // If they aren't banned, send the welcome message
        await sendWelcomeMessage(member, client);
    },
};
async function handleSoftBanCheck(member, profile) {
    // If there's no active ban (or profile), the user isn't banned
    // expired and unbanned bans count as not active, they stay in the history
    if (!GetActiveBan(profile))
        return false;
    try {
        await member.kick("User is softbanned");
        console.log(`Kicked ${member.user.tag} (ban list active)`);
    }
    catch (err) {
        console.log(`Failed to kick ${member.user.tag}:`, err);
    }
    return true; // User is banned
}
async function sendWelcomeMessage(member, client) {
    const channel = client.channels.cache
        .get(await GetServerConfig(member.guild.id, "welcomeChannel"));
    if (!client?.user || !channel?.permissionsFor(client.user)?.has(PermissionFlagsBits.SendMessages))
        return;
    // Filter out bots
    const humanMemberCount = member.guild.members.cache.filter((mm) => !mm.user.bot).size;
    const embed = new EmbedBuilder()
        .setTitle("Välkommen")
        .setDescription(`Gå in i <id:customize> för att skaffa en custom färg.\n Gå in i <id:browse> för att se kanaler som är gömda by default.`)
        .setColor(0x2b2d31)
        .setThumbnail(member.user.displayAvatarURL({ forceStatic: false }))
        .setFooter({
        text: `${humanMemberCount} Medlemmar ・ ${new Date().toLocaleString("sv-SE")}`,
    });
    await channel.send({
        content: `Välkommen ${member} till ${member.guild.name}!`,
        embeds: [embed],
    });
}
