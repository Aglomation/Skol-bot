import { Events } from "discord.js";
import { DeletePersonalData, getValueByKey, UpdateProfile } from "../utils/profileManager.js";
const PRIVACY_PREFERENCE = {
    KEEP_ALL: 1,
    DELETE_OPTIONAL: 2, // Default
    DELETE_ALL: 3,
};
export default {
    name: Events.GuildMemberRemove,
    once: false,
    async execute(member, _client) {
        const preference = await getValueByKey(member.id, member.guild.id, "privacyOption") || 2;
        switch (preference) {
            case PRIVACY_PREFERENCE.DELETE_ALL:
                // moderation history is kept as the privacy policy allows
                await DeletePersonalData(member.id, member.guild.id);
                console.log(`Deleted all data for user ${member.user.tag} (${member.id}) due to privacy preference.`);
                break;
            case PRIVACY_PREFERENCE.DELETE_OPTIONAL:
                // Delete optionally added data (currently only birthday)
                await UpdateProfile(member.id, member.guild.id, { birthday: null });
                console.log(`Deleted optionally added data for user ${member.user.tag} (${member.id}) due to privacy preference.`);
                break;
            case PRIVACY_PREFERENCE.KEEP_ALL:
                console.log(`Kept all data for user ${member.user.tag} (${member.id}) due to privacy preference.`);
                break;
            default:
                console.log(`Unknown privacy preference (${preference}) for user ${member.user.tag}. Doing nothing.`);
                break;
        }
    },
};
