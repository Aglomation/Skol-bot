/**
 * Gets the most relevant display name for a user in a guild.
 */
export const getDisplayName = (guild, userId, maxLength) => {
    if (!guild || !userId)
        return undefined;
    const member = guild?.members.cache.get(userId);
    const name = member?.displayName || member?.user.username;
    if (!name)
        return undefined;
    return maxLength ? name.slice(0, maxLength) : name;
};
/**
 * Counts members who have a primary role, and optionally filters by secondary roles.
 */
export const getRoleUserCount = (guild, primaryRole, needOneSecondary = false, secondaryRoles) => {
    if (!guild)
        return 0;
    const primaryRoleObj = guild.roles.cache.get(primaryRole);
    if (!primaryRoleObj)
        return 0;
    if (!secondaryRoles || secondaryRoles.length === 0) {
        return primaryRoleObj.members.size;
    }
    const validSecondaryRoles = secondaryRoles.filter((roleId) => roleId !== null);
    if (validSecondaryRoles.length === 0) {
        return primaryRoleObj.members.size;
    }
    const count = primaryRoleObj.members.filter(member => {
        if (needOneSecondary) {
            // Member needs AT LEAST ONE of the secondary roles
            return validSecondaryRoles.some((roleId) => member.roles.cache.has(roleId));
        }
        else {
            // Member needs ALL of the secondary roles
            return validSecondaryRoles.every((roleId) => member.roles.cache.has(roleId));
        }
    }).size;
    return count;
};
